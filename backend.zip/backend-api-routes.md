# RecipeNest — Backend API Routes

> Base URL: `https://api.recipenest.com/api/v1`  
> All protected routes require `Authorization: Bearer <JWT>` header.  
> Roles: `visitor` (unauthenticated), `chef`, `admin`

---

## Auth Router — `/api/v1/auth`

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/auth/register` | Public | Register new user. Body: `{ firstName, lastName, nickname, email, password }`. Hashes password with bcrypt, stores User doc in MongoDB. Returns `201` + user object (no password). |
| POST | `/auth/login` | Public | Login. Body: `{ email, password }`. Compares bcrypt hash. Returns signed JWT on match; generic error on failure (no field hint). |
| POST | `/auth/logout` | Protected | Invalidates client-side JWT (client deletes token; optionally adds to server-side denylist). |
| POST | `/auth/forgot-password` | Public | Body: `{ email }`. Generates time-limited reset token, hashes it, stores in DB, sends reset link via Nodemailer. Always returns `200` (no email enumeration). |
| POST | `/auth/reset-password/:token` | Public | Body: `{ newPassword }`. Validates token, hashes new password, saves. Invalidates token after use. |
| GET | `/auth/verify-email/:token` | Public | Validates email verification token. Marks `isVerified: true` on User document. |
| GET | `/auth/me` | Protected (chef/admin) | Returns currently authenticated user's profile data. Used on app load to rehydrate session. |

---

## Chef Router — `/api/v1/chefs`

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/chefs` | Public | Returns paginated, sortable list of all chefs with `name`, `specialisation`, `profileImage`, `recipeCount`. Query params: `?page=1&limit=12&sort=name&q=keyword` (FR14, FR15). |
| GET | `/chefs/:chefId` | Public | Returns full public chef profile: bio, specialisations, social links, published recipes. |
| POST | `/chefs/profile` | Protected (chef) | Creates chef profile. Body: `{ biography, specialisations, socialLinks }`. Profile photo handled separately via `/upload`. One profile per user enforced. |
| PUT | `/chefs/profile` | Protected (chef) | Updates own chef profile. Body: any subset of profile fields. Changes immediately visible. (FR07) |
| POST | `/chefs/profile/avatar` | Protected (chef) | Multipart form-data. Multer buffers, streams to Cloudinary, stores CDN URL in ChefProfile. (FR05) |
| GET | `/chefs/profile/me` | Protected (chef) | Returns authenticated chef's own profile (editable view, includes draft count, stats). |

---

## Recipe Router — `/api/v1/recipes`

### Public Endpoints

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/recipes` | Public | Paginated list of published recipes. Query params: `?page&limit&sort=date\|cookTime\|difficulty&cuisine=&difficulty=&category=&q=` (FR15, FR16). MongoDB text index used for `q`. |
| GET | `/recipes/:recipeId` | Public | Full recipe detail: title, description, ingredients, steps, images, chef info (populated via `chefId`). Increments view counter. |
| GET | `/recipes/chef/:chefId` | Public | All published recipes by a specific chef. Used on public Author Profile page. |

### Chef-Only Endpoints (Protected)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/recipes/my` | Protected (chef) | All recipes (published + draft) for the authenticated chef. Used in Text Oversight / My Recipes list. (FR17) |
| POST | `/recipes` | Protected (chef) | Create new recipe. Body: structured fields — `title`, `description`, `cuisineType`, `difficulty`, `prepTime`, `cookTime`, `ingredients[]`, `steps[]`, `isPublished`. Creates Recipe doc linked via `chefId`. (FR08) |
| PUT | `/recipes/:recipeId` | Protected (chef) | Update any recipe field. JWT middleware verifies `chefId` ownership before update. (FR11) |
| PUT | `/recipes/:recipeId/reorder-images` | Protected (chef) | Body: `{ stepImages: [ordered array of CDN URLs/IDs] }`. Saves new order to `stepImages` array in MongoDB. (FR10) |
| DELETE | `/recipes/:recipeId` | Protected (chef) | Soft or hard delete own recipe. Ownership verified via JWT. (FR12) |
| POST | `/recipes/:recipeId/share` | Protected (chef) | Generates and returns a deep-link shareable URL for the recipe. Optionally records share event. (FR13) |

### Image Upload Endpoints

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/recipes/:recipeId/images/hero` | Protected (chef) | Multipart upload. Replaces `mainImage` CDN URL in Recipe doc. |
| POST | `/recipes/:recipeId/images/steps` | Protected (chef) | Multipart upload (up to 5). Appends to `stepImages` array. |
| POST | `/recipes/:recipeId/images/result` | Protected (chef) | Multipart upload. Sets `resultImage` CDN URL. |
| DELETE | `/recipes/:recipeId/images/:slot` | Protected (chef) | Removes image from specified slot. Calls Cloudinary delete API to clean up. |

---

## Admin Router — `/api/v1/admin`

> All endpoints require `role: admin` claim in JWT. Enforced by `verifyAdmin` middleware.

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/admin/users` | Admin | Paginated user list with `name`, `email`, `role`, `isActive`, `createdAt`. Query: `?q=&status=active\|suspended`. (FR18) |
| GET | `/admin/users/:userId` | Admin | Full user profile detail for review. |
| PATCH | `/admin/users/:userId/suspend` | Admin | Sets `isActive: false` on User doc. Writes audit log entry. (FR18) |
| PATCH | `/admin/users/:userId/reinstate` | Admin | Sets `isActive: true`. Writes audit log entry. |
| DELETE | `/admin/users/:userId` | Admin | Permanently deletes user and all associated content. GDPR erasure. Writes audit log. |
| GET | `/admin/content` | Admin | Paginated list of all flagged or pending content (recipes + comments). Query: `?status=pending\|flagged\|all`. |
| PATCH | `/admin/content/:contentId/approve` | Admin | Sets content `status: published`. Writes audit log. |
| PATCH | `/admin/content/:contentId/reject` | Admin | Sets content `status: rejected`. Optionally notifies chef. Writes audit log. |
| DELETE | `/admin/content/:contentId` | Admin | Removes content document. Writes audit log. (FR18) |
| GET | `/admin/audit-log` | Admin | Paginated audit log. Query: `?page&limit&action=&userId=&from=&to=`. |
| GET | `/admin/dashboard-stats` | Admin | Aggregate counts: total users, total recipes, flagged items, new signups this week. |

---

## Analytics Router — `/api/v1/analytics`

> Used to power the Analytics screen on the Chef Dashboard.

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/analytics/chef` | Protected (chef) | Returns own aggregate stats: total views, total recipes, views per recipe, views over time (last 30 days). |
| GET | `/analytics/chef/recipes` | Protected (chef) | Per-recipe breakdown: title, views, shares, created date. Used for the analytics table/chart. |

---

## Search Router — `/api/v1/search`

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/search?q=keyword&type=recipe\|chef\|all` | Public | Unified search across recipes (text index on `title`, `description`, `ingredients`) and chefs (text index on `name`, `specialisations`). Returns mixed results array with `type` field. (FR15) |

---

## Notes

- All `POST`/`PUT` request bodies are `application/json` unless noted as multipart.
- Image uploads use `multipart/form-data` and are processed by Multer before Cloudinary.
- Error responses follow `{ success: false, message: "...", code: "ERROR_CODE" }` shape.
- Paginated responses follow `{ success: true, data: [], pagination: { page, limit, total, pages } }`.
- JWT payload shape: `{ userId, role, iat, exp }`.
