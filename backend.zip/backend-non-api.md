# RecipeNest — Non-API Backend Architecture

This file documents backend concerns that are **not** REST API endpoints: middleware, database models, utility services, folder structure, and configuration.

---

## Project Folder Structure

```
server/
├── config/
│   ├── db.js                   # MongoDB connection via Mongoose
│   ├── cloudinary.js           # Cloudinary SDK initialisation
│   └── nodemailer.js           # Nodemailer transporter config
│
├── middleware/
│   ├── auth.js                 # verifyToken — decodes JWT, attaches req.user
│   ├── verifyChef.js           # Ensures req.user.role === 'chef'
│   ├── verifyAdmin.js          # Ensures req.user.role === 'admin'
│   ├── verifyOwnership.js      # Checks recipe.chefId === req.user.userId
│   ├── upload.js               # Multer config (memory storage, file type/size validation)
│   ├── rateLimiter.js          # express-rate-limit config (auth routes: 10 req/15min)
│   ├── sanitise.js             # express-mongo-sanitize + xss-clean
│   └── errorHandler.js         # Global catch-all error middleware
│
├── models/
│   ├── User.js
│   ├── ChefProfile.js
│   ├── Recipe.js
│   ├── AuditLog.js
│   └── Category.js
│
├── routes/
│   ├── auth.routes.js
│   ├── chef.routes.js
│   ├── recipe.routes.js
│   ├── admin.routes.js
│   ├── analytics.routes.js
│   └── search.routes.js
│
├── controllers/
│   ├── auth.controller.js
│   ├── chef.controller.js
│   ├── recipe.controller.js
│   ├── admin.controller.js
│   ├── analytics.controller.js
│   └── search.controller.js
│
├── services/
│   ├── email.service.js        # Nodemailer helpers (sendResetEmail, sendWelcomeEmail)
│   ├── cloudinary.service.js   # Upload, delete, transform helpers
│   └── audit.service.js        # writeAuditLog() helper used by admin actions
│
├── utils/
│   ├── generateToken.js        # Signs JWT with userId + role payload
│   ├── hashToken.js            # Hashes reset tokens before DB storage
│   ├── apiResponse.js          # Standardised success/error response helpers
│   └── slugify.js              # Mongoose pre-save hook utility for slug generation
│
├── app.js                      # Express app setup (middleware stack, route mounting)
└── server.js                   # HTTP server entry point (process.env.PORT)
```

---

## Mongoose Data Models

### User.js
```
_id         ObjectId (PK)
firstName   String, required
lastName    String, required
nickname    String, unique
email       String, required, unique, lowercase
passwordHash String, required (bcrypt, select: false)
role        String, enum: ['visitor', 'chef', 'admin'], default: 'chef'
isActive    Boolean, default: true
isVerified  Boolean, default: false
resetToken  String (hashed, select: false)
resetTokenExpiry Date
createdAt   Date (timestamps: true)
updatedAt   Date (timestamps: true)
```
**Indexes:** `email` (unique), `resetToken`  
**Pre-save hook:** Hash password with bcrypt (saltRounds: 12) if modified  
**Instance method:** `comparePassword(plain)` → Boolean

---

### ChefProfile.js
```
_id             ObjectId (PK)
userId          ObjectId, ref: 'User', required, unique
biography       String
specialisations [String]
profileImage    String (Cloudinary CDN URL)
socialLinks     { instagram, facebook, twitter, website }
contactEmail    String
createdAt / updatedAt (timestamps)
```
**Indexes:** `userId` (unique)

---

### Recipe.js
```
_id           ObjectId (PK)
chefId        ObjectId, ref: 'ChefProfile', required
categoryId    ObjectId, ref: 'Category'
title         String, required
slug          String, unique
description   String
cuisineType   String
difficulty    String, enum: ['Easy', 'Medium', 'Hard']
prepTime      Number (minutes)
cookTime      Number (minutes)
ingredients   [{ name, quantity, unit }]
steps         [{ order, instruction, imageUrl }]
mainImage     String (CDN URL)
stepImages    [String] (ordered array of CDN URLs, max 5)
resultImage   String (CDN URL)
isPublished   Boolean, default: false
status        String, enum: ['draft', 'pending', 'published', 'rejected']
viewCount     Number, default: 0
shareCount    Number, default: 0
isFlagged     Boolean, default: false
createdAt / updatedAt (timestamps)
```
**Indexes:** `chefId`, `status`, `difficulty`, `cuisineType`, `cookTime`  
**Text index:** `{ title: 'text', description: 'text', 'ingredients.name': 'text' }` (enables FR15)  
**Pre-save hook:** `slugify(title)` → `slug`

---

### Category.js
```
_id   ObjectId
name  String, required, unique
slug  String, unique
```

---

### AuditLog.js
```
_id         ObjectId
adminId     ObjectId, ref: 'User'
action      String (e.g. 'SUSPEND_USER', 'DELETE_CONTENT', 'APPROVE_RECIPE')
targetType  String, enum: ['User', 'Recipe']
targetId    ObjectId
details     String
createdAt   Date (no updatedAt — logs are immutable)
```
**Indexes:** `adminId`, `createdAt`, `action`  
**Note:** No updates or deletes ever run on this collection.

---

## Middleware Stack (app.js order)

```
1. helmet()                    — Security headers (XSS, clickjacking, HSTS)
2. cors({ origin: ... })       — Whitelist frontend origin
3. express.json({ limit: '10kb' }) — Body parser with size cap
4. express-mongo-sanitize()    — Strip $ and . from req.body (NoSQL injection)
5. xss-clean()                 — Sanitise HTML in input strings
6. morgan('dev')               — Request logging in development
7. express-rate-limit           — Per-route, configured in rateLimiter.js
8. Routes mounted
9. errorHandler()              — Catch-all, returns { success: false, message }
```

---

## Authentication & Authorisation Flow

```
1. POST /auth/login
2. Controller calls comparePassword() on User instance
3. On match → generateToken({ userId, role }) → signed JWT (exp: 24h)
4. Client stores JWT in memory (NOT localStorage — XSS risk)
5. All subsequent requests: Authorization: Bearer <token>
6. auth.js middleware: jwt.verify() → attaches req.user = { userId, role }
7. verifyChef.js / verifyAdmin.js: checks req.user.role
8. verifyOwnership.js: loads resource, compares chefId to req.user.userId
```

---

## Image Upload Pipeline (Multer → Cloudinary)

```
1. Client sends multipart/form-data to image endpoint
2. Multer (memory storage) intercepts, validates: 
   - Allowed MIME types: image/jpeg, image/png, image/webp
   - Max file size: 5MB per file
3. multer fields config per slot: hero(1), steps(5), result(1), avatar(1)
4. cloudinary.service.js: cloudinary.uploader.upload_stream()
   - folder: 'recipenest/recipes/:recipeId' or 'recipenest/avatars'
   - transformation: { quality: 'auto', fetch_format: 'auto' } → serves WebP
5. Returns { secure_url, public_id }
6. Controller saves secure_url to Recipe/ChefProfile document
7. On image replace/delete: cloudinary.uploader.destroy(public_id)
```

---

## Email Service (Nodemailer)

```
Transporter: configured via environment variable SMTP credentials
             (SendGrid SMTP or Gmail OAuth2 for production)

Templates (HTML strings or Handlebars):
  - sendWelcomeEmail(user)        → triggered on successful registration
  - sendVerificationEmail(user, token)  → triggered on registration
  - sendPasswordResetEmail(user, resetUrl) → triggered on forgot-password
  - sendModerationEmail(chef, action)  → triggered when admin rejects content
```

---

## Environment Variables (.env)

```
NODE_ENV=development
PORT=5000

MONGO_URI=mongodb+srv://...

JWT_SECRET=<strong-random-secret>
JWT_EXPIRES_IN=24h

CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...

SMTP_HOST=...
SMTP_PORT=587
SMTP_USER=...
SMTP_PASS=...
EMAIL_FROM=noreply@recipenest.com

CLIENT_URL=http://localhost:3000
```

---

## What is NOT an API Route

The following concerns live entirely server-side and are never exposed as REST endpoints:

| Concern | Location | Notes |
|---------|----------|-------|
| Password hashing | `User.js` pre-save hook | bcrypt, never returned in responses |
| Token hashing | `utils/hashToken.js` | Reset tokens stored hashed, compared hashed |
| Slug generation | `Recipe.js` pre-save hook | Auto-derived from title |
| Audit log writes | `services/audit.service.js` | Called internally by admin controllers |
| Cloudinary cleanup | `services/cloudinary.service.js` | Called on image replace/delete, not client-triggered |
| DB indexing | Mongoose schema definitions | Text indexes, compound indexes |
| CORS whitelist | `app.js` config | Not a route, not accessible to clients |
| Rate limiting | `middleware/rateLimiter.js` | Transparent to client beyond 429 response |
| Input sanitisation | `middleware/sanitise.js` | Runs before all routes, invisible to client |
