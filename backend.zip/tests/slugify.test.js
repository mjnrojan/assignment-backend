const slugify = require("../src/utils/slugify");

describe("slugify", () => {
  it("should convert a simple string to a slug", () => {
    expect(slugify("Hello World")).toBe("hello-world");
  });

  it("should handle multiple spaces", () => {
    expect(slugify("Too   Many   Spaces")).toBe("too-many-spaces");
  });

  it("should remove special characters", () => {
    expect(slugify("Hello! @World#")).toBe("hello-world");
  });

  it("should handle leading and trailing whitespace", () => {
    expect(slugify("  padded string  ")).toBe("padded-string");
  });

  it("should collapse multiple hyphens", () => {
    expect(slugify("a---b---c")).toBe("a-b-c");
  });

  it("should handle empty string", () => {
    expect(slugify("")).toBe("");
  });

  it("should handle undefined input", () => {
    expect(slugify()).toBe("");
  });

  it("should handle numbers", () => {
    expect(slugify("Recipe 101")).toBe("recipe-101");
  });
});
