const request = require("supertest");
const app = require("../src/app");

// These tests only check middleware guards (auth/role checks).
// Tests that hit the database (GET /recipes, GET /chefs) are skipped
// because they require a running MongoDB instance.

describe("Recipe Routes", () => {
  describe("POST /api/v1/recipes", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app)
        .post("/api/v1/recipes")
        .send({ title: "Test Recipe" });
      expect(res.statusCode).toBe(401);
      expect(res.body.success).toBe(false);
    });
  });
});

describe("Chef Routes", () => {
  describe("POST /api/v1/chefs/profile", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app).post("/api/v1/chefs/profile").send({});
      expect(res.statusCode).toBe(401);
    });
  });
});

describe("Admin Routes", () => {
  describe("GET /api/v1/admin/users", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app).get("/api/v1/admin/users");
      expect(res.statusCode).toBe(401);
    });
  });

  describe("GET /api/v1/admin/dashboard-stats", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app).get("/api/v1/admin/dashboard-stats");
      expect(res.statusCode).toBe(401);
    });
  });
});

describe("Analytics Routes", () => {
  describe("GET /api/v1/analytics/chef", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app).get("/api/v1/analytics/chef");
      expect(res.statusCode).toBe(401);
    });
  });
});
