const hashToken = require("../src/utils/hashToken");

describe("hashToken", () => {
  it("should return a 64-char hex string for any input", () => {
    const result = hashToken("test-token");
    expect(typeof result).toBe("string");
    expect(result).toHaveLength(64);
    expect(result).toMatch(/^[a-f0-9]{64}$/);
  });

  it("should return the same hash for the same input", () => {
    const a = hashToken("same-token");
    const b = hashToken("same-token");
    expect(a).toBe(b);
  });

  it("should return different hashes for different inputs", () => {
    const a = hashToken("token-1");
    const b = hashToken("token-2");
    expect(a).not.toBe(b);
  });
});
