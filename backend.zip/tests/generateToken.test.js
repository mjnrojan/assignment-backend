const jwt = require("jsonwebtoken");
const generateToken = require("../src/utils/generateToken");

describe("generateToken", () => {
  it("should return a valid JWT token", () => {
    const token = generateToken({ userId: "abc123", role: "chef" });
    expect(typeof token).toBe("string");
    expect(token.split(".")).toHaveLength(3);
  });

  it("should embed userId and role in the payload", () => {
    const token = generateToken({ userId: "user-42", role: "admin" });
    const decoded = jwt.decode(token);
    expect(decoded.userId).toBe("user-42");
    expect(decoded.role).toBe("admin");
  });

  it("should set an expiry on the token", () => {
    const token = generateToken({ userId: "user-1", role: "chef" });
    const decoded = jwt.decode(token);
    expect(decoded.exp).toBeDefined();
    expect(decoded.iat).toBeDefined();
    expect(decoded.exp).toBeGreaterThan(decoded.iat);
  });
});
