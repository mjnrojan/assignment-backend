const errorHandler = require("../src/middleware/errorHandler");

const mockReq = {};
const mockNext = jest.fn();

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  res.headersSent = false;
  return res;
};

describe("errorHandler middleware", () => {
  it("should return 500 for generic errors", () => {
    const res = mockRes();
    const err = new Error("Something broke");
    errorHandler(err, mockReq, res, mockNext);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({
      success: false,
      message: "Something broke",
      code: "INTERNAL_ERROR",
    });
  });

  it("should use error's statusCode when set", () => {
    const res = mockRes();
    const err = new Error("Not found");
    err.statusCode = 404;
    err.code = "NOT_FOUND";
    errorHandler(err, mockReq, res, mockNext);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({
      success: false,
      message: "Not found",
      code: "NOT_FOUND",
    });
  });

  it("should call next when headers already sent", () => {
    const res = mockRes();
    res.headersSent = true;
    const err = new Error("After headers");
    const next = jest.fn();
    errorHandler(err, mockReq, res, next);

    expect(next).toHaveBeenCalledWith(err);
    expect(res.status).not.toHaveBeenCalled();
  });
});
