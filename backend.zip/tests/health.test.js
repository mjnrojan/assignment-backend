const request = require("supertest");
const app = require("../src/app");

describe("Health Check", () => {
  it("GET / should return API info", async () => {
    const res = await request(app).get("/");
    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.message).toBe("RecipeNest Backend API");
    expect(res.body.version).toBe("1.0.0");
    expect(res.body.status).toBe("running");
  });

  it("GET /nonexistent should return 404", async () => {
    const res = await request(app).get("/nonexistent");
    expect(res.statusCode).toBe(404);
    expect(res.body.success).toBe(false);
  });
});
