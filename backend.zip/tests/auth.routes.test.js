const request = require("supertest");
const app = require("../src/app");

// These tests only check middleware guards and validation.
// Tests that hit mongoose (register, login) are skipped
// because they require a running MongoDB instance.

describe("Auth Routes", () => {
  describe("GET /api/v1/auth/me", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app).get("/api/v1/auth/me");
      expect(res.statusCode).toBe(401);
      expect(res.body.success).toBe(false);
    });
  });

  describe("POST /api/v1/auth/logout", () => {
    it("should reject unauthenticated requests with 401", async () => {
      const res = await request(app).post("/api/v1/auth/logout");
      expect(res.statusCode).toBe(401);
    });
  });

  describe("GET /api/v1/auth/me with invalid token", () => {
    it("should reject malformed bearer tokens", async () => {
      const res = await request(app)
        .get("/api/v1/auth/me")
        .set("Authorization", "Bearer invalid-token-here");
      expect(res.statusCode).toBe(401);
      expect(res.body.success).toBe(false);
    });
  });

  describe("GET /api/v1/auth/me without Bearer prefix", () => {
    it("should reject non-bearer auth header", async () => {
      const res = await request(app)
        .get("/api/v1/auth/me")
        .set("Authorization", "Basic sometoken");
      expect(res.statusCode).toBe(401);
    });
  });
});
