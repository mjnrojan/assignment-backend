const { successResponse, errorResponse } = require("../src/utils/apiResponse");

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
};

describe("apiResponse", () => {
  describe("successResponse", () => {
    it("should return success true with data and message", () => {
      const res = mockRes();
      successResponse(res, 200, { id: 1 }, null, "Done");

      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: "Done",
        data: { id: 1 },
      });
    });

    it("should include pagination when provided", () => {
      const res = mockRes();
      const pagination = { page: 1, limit: 10, total: 50, pages: 5 };
      successResponse(res, 200, [], pagination, "List");

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: "List",
        data: [],
        pagination,
      });
    });

    it("should default message to OK", () => {
      const res = mockRes();
      successResponse(res, 200, null);

      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: "OK",
        data: null,
      });
    });
  });

  describe("errorResponse", () => {
    it("should return success false with message and code", () => {
      const res = mockRes();
      errorResponse(res, 404, "Not found", "NOT_FOUND");

      expect(res.status).toHaveBeenCalledWith(404);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: "Not found",
        code: "NOT_FOUND",
      });
    });

    it("should include details when provided", () => {
      const res = mockRes();
      errorResponse(res, 400, "Validation", "VALIDATION_ERROR", { field: "email" });

      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: "Validation",
        code: "VALIDATION_ERROR",
        details: { field: "email" },
      });
    });
  });
});
