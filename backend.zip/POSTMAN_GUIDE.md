# RecipeNest API v2.0.0 — Postman Testing Guide

## 🚀 Project Refactor: Migration to Social Creator Platform

RecipeNest has been transformed from a legacy Role-Based (Chef/Visitor) system into a **Universal Social Creator Platform**. 

### 🔑 Key Architectural Changes:
1. **Universal Model**: Removed the "Chef" role requirement. Every registered user now has a public **Profile** and can create/share recipes.
2. **Social Graph**: Implemented a robust **Follow/Following** system.
3. **Privacy Controls**: Users can now toggle **`isPrivate`** status. Recipes from private accounts are only visible to accepted followers.
4. **Professional Mode**: Users can toggle **`isProfessional`** status to unlock the **Creator Analytics Suite** (Advanced reach and engagement metrics).
5. **Engagement Metrics**: Added native support for **Likes**, **Comments**, **Saves (Bookmarks)**, **Views**, and **Shares**.
6. **Hierarchical Categorization**: Recipes now support a tree-based category system (e.g., `Drinks` > `Alcoholic` > `Cocktails`) for advanced client-side filtering.

---

## Prerequisites

1. **MongoDB running** on `localhost:27017`
2. **Server running**: `npm run dev` (starts on port 8080)
3. **Base URL**: `http://localhost:8080`

---

## 1. Quick Setup in Postman

1. Create a new Collection: **RecipeNest v2**
2. Set a Collection variable: `baseUrl` = `http://localhost:8080`
3. Set a Collection variable: `token` = (filled after login)
4. Add Header: `Authorization: Bearer {{token}}`

---

## 2. Auth & Settings (`/api/users`)

### 2.1 Register — `POST /api/users/register`
Creates a User and auto-generates their Social Profile.
```json
{
  "firstName": "Alice",
  "lastName": "Cook",
  "username": "alice_cooks",
  "email": "alice@test.com",
  "password": "Pass123!"
}
```

### 2.2 Toggle Settings — `PATCH /api/users/settings`
**Auth required** 🔒
Toggle privacy or professional career mode.
```json
{
  "isPrivate": true,
  "isProfessional": true
}
```

---

## 3. Profile Routes (`/api/profiles`)

### 3.1 Get My Profile — `GET /api/profiles/me`
**Auth required** 🔒
Returns your profile, stats, and recipe counts (drafts/published).

### 3.2 Public Profile — `GET /api/profiles/:userId`
**Optional Auth** 👤
Returns public bio and stats. If the account is private, content may be limited.

---

## 4. Social & Engagement (`/api/social`)

### 4.1 Follow User — `POST /api/social/follow/:userId`
**Auth required** 🔒
- If target is Public: Follows immediately (`status: accepted`).
- If target is Private: Creates a request (`status: pending`).

### 4.2 Manage Requests — `PATCH /api/social/follow-requests/:requestId/accept`
**Auth required** 🔒
Accept or reject (`/reject`) pending followers.

### 4.3 Like & Save
- `POST /api/social/like/:recipeId`
- `POST /api/social/save/:recipeId`

---

## 5. Recipe Routes (`/api/recipes`)

### 5.1 List Recipes — `GET /api/recipes`
**Optional Auth** 👤
Filters: `category`, `cuisine`, `difficulty`, `q` (search).
*Note: Automatically hides private account content unless you follow them.*

### 5.2 Create Recipe — `POST /api/recipes`
**Auth required** 🔒
```json
{
  "title": "Nepalese Momo",
  "ingredients": [{ "name": "Flour" }, { "name": "Minced Meat" }],
  "steps": [{ "order": 1, "instruction": "Make dough" }],
  "status": "published"
}
```

---

## 6. Advanced Analytics (`/api/analytics`)
**Auth required** 🔒 | **Professional Mode Required** 📈

### 6.1 Profile Overview — `GET /api/analytics/profile`
Returns unique reach, total engagement, and follower growth trends.

### 6.2 Recipe Analytics — `GET /api/analytics/recipe/:recipeId`
Deep dive into specific recipe performance.

---

## 7. Search & Discovery (`/api/search`)

### 7.1 Category Tree — `GET /api/search/categories`
Returns the full hierarchical category structure for sidebars/filters.

---

## 📊 Error Codes Reference
| Code | Meaning |
|------|---------|
| `PRIVATE_ACCOUNT` | 403 - Cannot view content from this private user. |
| `PROFESSIONAL_MODE_REQUIRED` | 403 - Switch to professional mode in settings to view. |
| `UNAUTHORIZED` | 401 - Missing or invalid Bearer token. |
